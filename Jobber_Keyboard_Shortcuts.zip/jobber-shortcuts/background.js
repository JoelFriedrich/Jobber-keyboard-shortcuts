// background.js
// All shortcuts are now handled via keydown listener in content.js.
// This file is kept as the service worker entry point required by manifest v3.
