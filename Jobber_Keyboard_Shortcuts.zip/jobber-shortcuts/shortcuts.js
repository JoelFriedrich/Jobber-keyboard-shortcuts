// shortcuts.js
// ─────────────────────────────────────────────────────────────────────────────
// Single source of truth for all Jobber Shortcuts.
// To add a new shortcut:
//   1. Add a matching entry here in SHORTCUTS
//   2. Add the key combo to KEY_MAP in content.js
//   3. That's it.
// ─────────────────────────────────────────────────────────────────────────────

const SHORTCUTS = {

  save: {
    label: "Save",
    keys: "⌘ ⇧ S",
    keysWin: "Ctrl + Shift + S",
    description: "Save the current record",
    action: "clickByText",
    target: ["Save", "Save changes", "Save & close", "Save invoice", "Save job", "Save quote"],
    scope: "global",
  },

  edit: {
    label: "Edit",
    keys: "⌘ ⇧ E",
    keysWin: "Ctrl + Shift + E",
    description: "Edit the current record or modal",
    action: "clickByText",
    target: ["Edit"],
    scope: "global",
  },

  primaryAction: {
    label: "Primary action",
    keys: "⌘ ⇧ O",
    keysWin: "Ctrl + Shift + O",
    description: "Click the primary (green) button on the current page or modal",
    action: "clickPrimary",
    // Jobber's primary button fingerprint: amVSJ50CiOo- + TrzCxs3OEpM- (both required).
    
    target: "amVSJ50CiOo-", // paired with TrzCxs3OEpM- in content.js selector
    // Safety exclusion list — never click these even if they match the primary class
    exclude: ["delete", "remove", "archive", "void", "cancel"],
    scope: "global",
  },

  newClient: {
    label: "New client",
    keys: "⌘ ⇧ C",
    keysWin: "Ctrl + Shift + C",
    description: "Quick create a new client",
    action: "navigate",
    target: "https://secure.getjobber.com/clients/new?tracking_origin=quick_create",
    scope: "global",
  },

  newRequest: {
    label: "New request",
    keys: "⌘ ⇧ R",
    keysWin: "Ctrl + Shift + R",
    description: "Quick create a new request",
    action: "navigate",
    target: "https://secure.getjobber.com/requests/new?source=quick_create",
    scope: "global",
  },

  scheduleMonth: {
    label: "Month view",
    keys: "⌘ ⇧ M",
    keysWin: "Ctrl + Shift + M",
    description: "Switch schedule to month view",
    action: "clickRadio",
    target: "month",
    scope: "schedule",
  },

  scheduleWeek: {
    label: "Week view",
    keys: "⌘ ⇧ L",
    keysWin: "Ctrl + Shift + L",
    description: "Switch schedule to week view",
    action: "clickRadio",
    target: "week",
    scope: "schedule",
  },

  scheduleDay: {
    label: "Day view",
    keys: "⌘ ⇧ D",
    keysWin: "Ctrl + Shift + D",
    description: "Switch schedule to day view",
    action: "clickRadio",
    target: "day",
    scope: "schedule",
  },

  scheduleUnscheduled: {
    label: "Toggle unscheduled",
    keys: "⌘ ⇧ U",
    keysWin: "Ctrl + Shift + U",
    description: "Toggle unscheduled appointments panel",
    action: "clickByAriaLabel",
    target: "Unscheduled appointments",
    scope: "schedule",
  },

  scheduleMap: {
    label: "Toggle map",
    keys: "⌘ ⇧ K",
    keysWin: "Ctrl + Shift + K",
    description: "Toggle map view",
    action: "clickByAriaLabel",
    target: "Toggle Map",
    scope: "schedule",
  },

};

if (typeof window !== "undefined") {
  window.JOBBER_SHORTCUTS = SHORTCUTS;
}
