// content.js
// All shortcuts handled via keydown listener.

const KEY_MAP = {
  "meta+shift+s": "save",
  "meta+shift+e": "edit",
  "meta+shift+o": "primaryAction",
  
  "meta+shift+c": "newClient",
  "meta+shift+r": "newRequest",
  "meta+shift+m": "scheduleMonth",
  "meta+shift+l": "scheduleWeek",
  "meta+shift+d": "scheduleDay",
  "meta+shift+u": "scheduleUnscheduled",
  "meta+shift+k": "scheduleMap",
};

document.addEventListener("keydown", (e) => {
  const key = [
    e.metaKey  ? "meta"  : null,
    e.ctrlKey  ? "ctrl"  : null,
    e.shiftKey ? "shift" : null,
    e.key.length === 1 ? e.key.toLowerCase() : e.key,
  ].filter(Boolean).join("+");

  const commandName = KEY_MAP[key];
  if (!commandName) return;

  const shortcut = window.JOBBER_SHORTCUTS?.[commandName];
  if (!shortcut) return;

  e.preventDefault();
  executeShortcut(shortcut);
});

// ─────────────────────────────────────────────────────────────────────────────
// Executor
// ─────────────────────────────────────────────────────────────────────────────
function executeShortcut(shortcut) {
  if (shortcut.scope === "schedule" && !window.location.pathname.startsWith("/schedule")) {
    showToast("⚠️ This shortcut only works on the Schedule page.", "warn");
    return;
  }

  switch (shortcut.action) {
    case "clickByText":      handleClickByText(shortcut);      break;
    case "clickByAriaLabel": handleClickByAriaLabel(shortcut); break;
    case "clickRadio":       handleClickRadio(shortcut);       break;
    case "clickPrimary":     handleClickPrimary(shortcut);     break;
    case "navigate":         handleNavigate(shortcut);         break;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Actions
// ─────────────────────────────────────────────────────────────────────────────
function handleClickByText(shortcut) {
  const targets = shortcut.target.map((t) => t.toLowerCase());
  const candidates = Array.from(
    document.querySelectorAll('button, a, [role="button"], input[type="submit"], span')
  );
  const matches = candidates.filter((el) => {
    const text = (el.innerText || el.value || el.getAttribute("aria-label") || "")
      .trim().toLowerCase();
    return targets.some((t) => text === t || text.startsWith(t));
  });

  if (matches.length === 0) {
    showToast(`⚠️ No "${shortcut.label}" button found.`, "warn");
    return;
  }
  const target = matches.find((el) => isVisible(el) && !el.disabled) || matches[0];
  target.click();
  showToast(`✓ ${shortcut.label}`, "success");
}

function handleClickByAriaLabel(shortcut) {
  const el = document.querySelector(`[aria-label="${shortcut.target}"]`);
  if (!el) {
    showToast(`⚠️ "${shortcut.label}" button not found.`, "warn");
    return;
  }
  el.click();
  showToast(`✓ ${shortcut.label}`, "success");
}

function handleClickRadio(shortcut) {
  const el = document.querySelector(`input[type="radio"][value="${shortcut.target}"]`);
  if (!el) {
    showToast(`⚠️ "${shortcut.label}" option not found.`, "warn");
    return;
  }
  el.click();
  showToast(`✓ ${shortcut.label}`, "success");
}

function handleClickPrimary(shortcut) {
  const exclude = shortcut.exclude || [];

  // Primary button fingerprint: must have BOTH amVSJ50CiOo- AND TrzCxs3OEpM-
  // Verified across: New Job, Collect Payment, Details, Find a Time, Create Invoice
  // Safely excludes: More Actions, Cancel, Edit (modal), nav buttons
  const candidates = Array.from(
    document.querySelectorAll("button.amVSJ50CiOo-.TrzCxs3OEpM-")
  );

  // Filter: visible, not disabled, not on exclusion list
  const safe = candidates.filter((el) => {
    if (!isVisible(el) || el.disabled) return false;
    const text = (el.innerText || el.getAttribute("aria-label") || "").trim().toLowerCase();
    return !exclude.some((word) => text.includes(word));
  });

  if (safe.length === 0) {
    showToast("⚠️ No primary action button found.", "warn");
    return;
  }

  // If a modal/dialog is open, prefer buttons inside it
  const modal = document.querySelector('[role="dialog"], [role="alertdialog"]');
  const target = modal
    ? safe.find((el) => modal.contains(el)) || safe[safe.length - 1]
    : safe[safe.length - 1]; // last visible primary = most prominent CTA

  const label = (target.innerText || target.getAttribute("aria-label") || "Primary action").trim();
  target.click();
  showToast(`✓ ${label}`, "success");
}

function handleNavigate(shortcut) {
  showToast(`✓ ${shortcut.label}`, "success");
  window.location.href = shortcut.target;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────
function isVisible(el) {
  const rect = el.getBoundingClientRect();
  return (
    rect.width > 0 &&
    rect.height > 0 &&
    window.getComputedStyle(el).visibility !== "hidden" &&
    window.getComputedStyle(el).display !== "none"
  );
}

function showToast(message, type = "success") {
  document.getElementById("jbs-toast")?.remove();
  const toast = document.createElement("div");
  toast.id = "jbs-toast";
  toast.textContent = message;

  const colors = {
    success: { bg: "#1a1a2e", border: "#8ACC33", text: "#8ACC33" },
    warn:    { bg: "#1a1a2e", border: "#facc15", text: "#facc15" },
  };
  const c = colors[type] || colors.success;

  Object.assign(toast.style, {
    position: "fixed",
    bottom: "24px",
    right: "24px",
    zIndex: "99999",
    padding: "10px 16px",
    borderRadius: "8px",
    fontSize: "13px",
    fontFamily: "monospace",
    fontWeight: "600",
    letterSpacing: "0.05em",
    background: c.bg,
    border: `1px solid ${c.border}`,
    color: c.text,
    boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
    opacity: "0",
    transition: "opacity 0.15s ease",
    pointerEvents: "none",
  });

  document.body.appendChild(toast);
  requestAnimationFrame(() => (toast.style.opacity = "1"));
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 200);
  }, 2000);
}
