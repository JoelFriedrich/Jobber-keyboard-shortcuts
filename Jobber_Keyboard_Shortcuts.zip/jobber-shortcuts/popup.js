// popup.js
const isMac = navigator.platform.toUpperCase().includes("MAC");

const statusDot = document.getElementById("statusDot");
const content = document.getElementById("content");

chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  const onJobber = tab?.url?.includes("secure.getjobber.com");
  const onSchedule = tab?.url?.includes("secure.getjobber.com/schedule");

  statusDot.style.background = onJobber ? "#8ACC33" : "#475569";
  statusDot.style.boxShadow = onJobber ? "0 0 6px #8ACC33" : "none";

  if (!onJobber) {
    content.innerHTML = `
      <div class="not-jobber">
        <span>🔒</span>
        Navigate to<br /><strong style="color:#94a3b8">secure.getjobber.com</strong><br />to activate shortcuts
      </div>
    `;
    return;
  }

  const shortcuts = window.JOBBER_SHORTCUTS || {};
  const global = Object.entries(shortcuts).filter(([, s]) => s.scope === "global");
  const schedule = Object.entries(shortcuts).filter(([, s]) => s.scope === "schedule");

  content.innerHTML = "";

  renderGroup("Everywhere on Jobber", global, content, isMac);

  const scheduleSection = renderGroup("Schedule page only", schedule, content, isMac);

  // Dim schedule shortcuts if not on schedule page
  if (!onSchedule) {
    scheduleSection.style.opacity = "0.4";
    const note = document.createElement("p");
    note.style.cssText = "font-size:10px;color:#475569;padding:0 18px 10px;margin:0;";
    note.textContent = "Navigate to the Schedule page to use these.";
    scheduleSection.after(note);
  }
});

function renderGroup(label, entries, parent, isMac) {
  const section = document.createElement("div");

  const heading = document.createElement("div");
  heading.className = "section-label";
  heading.textContent = label;
  section.appendChild(heading);

  const list = document.createElement("div");
  list.className = "shortcut-list";

  entries.forEach(([, shortcut]) => {
    const keys = isMac ? shortcut.keys : shortcut.keysWin;
    const keyParts = keys.split("+").map(k => k.trim());

    const row = document.createElement("div");
    row.className = "shortcut-row";
    row.innerHTML = `
      <div class="shortcut-info">
        <div class="shortcut-name">${shortcut.label}</div>
        <div class="shortcut-desc">${shortcut.description}</div>
      </div>
      <div class="keys">
        ${keyParts.map(k => `<kbd>${k}</kbd>`).join('<span style="color:#334155;font-size:10px">+</span>')}
      </div>
    `;
    list.appendChild(row);
  });

  section.appendChild(list);
  parent.appendChild(section);
  return section;
}
